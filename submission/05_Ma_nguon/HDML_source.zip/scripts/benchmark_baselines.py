#!/usr/bin/env python3
from __future__ import annotations

import argparse
import json
import hashlib
from datetime import datetime, timezone
import logging
import time
from pathlib import Path
from typing import Any
import gymnasium as gym
import numpy as np
import torch
import torch.nn as nn

from hdml.models import (
    HDMLModel,
    DecisionTransformerBaseline,
    DecisionRNNBaseline,
    DiffusionPolicyBaseline,
    IQLBaseline,
    MLPBCBaseline,
)
from hdml.evaluation.perturbations import SensorNoisePerturbation, ForceImpulsePerturbation
from hdml.utils.metrics import compute_action_smoothness, get_d4rl_normalized_score
from hdml.utils.config import HDMLConfig

logging.basicConfig(level=logging.INFO, format="%(asctime)s [%(levelname)s] %(name)s: %(message)s")
logger = logging.getLogger(__name__)

# Standard D4RL reference scores are defined centrally in hdml/utils/metrics.py
# (official D4RL library constants). Imported via get_d4rl_normalized_score.


def evaluate_policy(
    model: nn.Module,
    model_type: str,
    env_name: str = "HalfCheetah-v5",
    num_episodes: int = 5,
    context_length: int = 20,
    target_return: float = 4000.0,
    scale_return: float = 1000.0,
    state_mean: np.ndarray | None = None,
    state_std: np.ndarray | None = None,
    with_perturbations: bool = False,
    macro_interval: int = 1,
    seed: int = 42,
    device: torch.device = torch.device("cuda"),
) -> dict[str, Any]:
    """Evaluate a single policy architecture across benchmark episodes."""
    if macro_interval != 1:
        raise ValueError("Only macro_interval=1 is supported")
    if num_episodes < 1:
        raise ValueError("num_episodes must be positive")
    torch.manual_seed(seed)
    if device.type == "cuda":
        torch.cuda.manual_seed_all(seed)
    env = gym.make(env_name)
    obs_dim = env.observation_space.shape[0]  # type: ignore
    act_dim = env.action_space.shape[0]        # type: ignore

    st_mean = state_mean if state_mean is not None else np.zeros(obs_dim, dtype=np.float32)
    st_std = state_std if state_std is not None else np.ones(obs_dim, dtype=np.float32)

    sensor_noise = SensorNoisePerturbation(noise_std=0.05, seed=seed) if with_perturbations else None
    force_perturb = ForceImpulsePerturbation(impulse_prob=0.05, force_magnitude=0.6, seed=seed) if with_perturbations else None

    returns: list[float] = []
    lengths: list[int] = []
    smoothnesses: list[float] = []
    latencies: list[float] = []

    model = model.to(device)
    model.eval()
    torch.manual_seed(seed)
    if device.type == "cuda":
        torch.cuda.manual_seed_all(seed)

    for ep in range(num_episodes):
        obs, _ = env.reset(seed=seed + ep)
        history_states: list[np.ndarray] = []
        history_actions: list[np.ndarray] = []
        history_rtgs: list[float] = []
        history_timesteps: list[int] = []

        ep_actions: list[np.ndarray] = []
        ep_rewards: list[float] = []

        current_rtg = target_return
        hx = None
        current_subgoal = None

        for t in range(1000):
            raw_obs = np.asarray(obs, dtype=np.float32)
            if sensor_noise is not None:
                raw_obs = sensor_noise.apply(raw_obs)

            norm_obs = (raw_obs - st_mean) / st_std
            scaled_rtg = current_rtg / scale_return

            history_states.append(norm_obs)
            history_rtgs.append(scaled_rtg)
            history_timesteps.append(t)
            if len(history_actions) == 0:
                history_actions.append(np.zeros(act_dim, dtype=np.float32))

            # Build causal context without artificial zero padding
            ctx_len = min(len(history_states), context_length)
            ctx_states = np.array(history_states[-ctx_len:], dtype=np.float32)
            ctx_actions = np.array(history_actions[-ctx_len:], dtype=np.float32)
            ctx_rtgs = np.array(history_rtgs[-ctx_len:], dtype=np.float32).reshape(-1, 1)
            ctx_time = np.array(history_timesteps[-ctx_len:], dtype=np.int64)

            t_states = torch.from_numpy(ctx_states).unsqueeze(0).to(device)
            t_actions = torch.from_numpy(ctx_actions).unsqueeze(0).to(device)
            t_rtgs = torch.from_numpy(ctx_rtgs).unsqueeze(0).to(device)
            t_time = torch.from_numpy(ctx_time).unsqueeze(0).to(device)

            if device.type == "cuda":
                torch.cuda.synchronize(device)
            step_t0 = time.perf_counter()
            with torch.inference_mode():
                if model_type == "hdml":
                    action_t, hx, info = model.get_action(
                        states=t_states, rtgs=t_rtgs, actions=t_actions, timesteps=t_time, hx=None
                    )
                elif model_type == "diffusion":
                    action_t = model.get_action(states=t_states, rtgs=t_rtgs, actions=t_actions, timesteps=t_time)
                elif model_type == "dt":
                    action_t = model.get_action(states=t_states, rtgs=t_rtgs, actions=t_actions, timesteps=t_time)
                elif model_type == "iql":
                    t_cur_state = torch.from_numpy(norm_obs).unsqueeze(0).to(device)
                    action_t = model.get_action(states=t_cur_state)
                elif model_type == "rnn":
                    action_t, hx = model.get_action(states=t_states, rtgs=t_rtgs, actions=t_actions, timesteps=t_time, hx=None)
                elif model_type == "mlp":
                    t_cur_state = torch.from_numpy(norm_obs).unsqueeze(0).to(device)
                    t_cur_rtg = torch.tensor([[scaled_rtg]], dtype=torch.float32, device=device)
                    action_t = model.get_action(t_cur_state, t_cur_rtg)
                else:
                    raise ValueError(f"Unknown model type: {model_type}")

            if device.type == "cuda":
                torch.cuda.synchronize(device)
            step_t1 = time.perf_counter()
            latencies.append((step_t1 - step_t0) * 1000.0)

            if action_t.ndim == 3:  # (B, chunk_size, action_dim)
                action = action_t[0, 0, :].cpu().numpy().astype(np.float32)
            else:  # (B, action_dim)
                action = action_t[0, :].cpu().numpy().astype(np.float32)
                
            action = np.clip(action, -1.0, 1.0)
            # Append the executed action; the input action at the final context
            # position is thus a_{t-1} (causal no-leakage convention).
            history_actions.append(action)

            exec_action = action
            if force_perturb is not None:
                exec_action = force_perturb.apply_action_perturbation(action)

            next_obs, reward, terminated, truncated, _ = env.step(exec_action)
            ep_actions.append(action)
            ep_rewards.append(float(reward))
            current_rtg -= float(reward)
            obs = next_obs

            if terminated or truncated:
                break

        actions_arr = np.array(ep_actions, dtype=np.float32)
        raw_ret = float(sum(ep_rewards))
        returns.append(raw_ret)
        lengths.append(len(ep_rewards))
        smoothnesses.append(compute_action_smoothness(actions_arr))

    env.close()

    params_count = sum(p.numel() for p in model.parameters())
    mean_ret = float(np.mean(returns))
    std_ret = float(np.std(returns))
    mean_lat = float(np.mean(latencies))
    freq_hz = 1000.0 / max(1e-4, mean_lat)
    norm_scores = np.array([get_d4rl_normalized_score(env_name, r) for r in returns], dtype=np.float32)

    return {
        "model_type": model_type,
        "mean_return": mean_ret,
        "std_return": std_ret,
        "d4rl_normalized_score": float(np.mean(norm_scores)),
        "returns_array": np.array(returns, dtype=np.float32),
        "norm_scores_array": norm_scores,
        "mean_length": float(np.mean(lengths)),
        "episode_completion_rate": float(sum(l >= 1000 for l in lengths) / max(1, len(lengths)) * 100.0),
        "mean_smoothness_jerk": float(np.mean(smoothnesses)),
        "mean_latency_ms": mean_lat,
        "frequency_hz": freq_hz,
        "params_count": params_count,
    }


def load_baseline_checkpoint(
    model: nn.Module,
    ckpt_dir: Path,
    model_type: str,
    device: torch.device,
) -> bool:
    """Load a trained baseline checkpoint if available.

    Missing checkpoints are fatal; random policies cannot enter a trained comparison.
    """
    ckpt_path = ckpt_dir / f"{model_type}_best.pt"
    if ckpt_path.exists():
        ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)
        model.load_state_dict(ckpt["model_state_dict"])
        logger.info(f"Loaded trained baseline checkpoint: {ckpt_path}")
        return True
    raise FileNotFoundError(f"Missing trained baseline checkpoint: {ckpt_path}")


def main() -> None:
    parser = argparse.ArgumentParser(description="Benchmark HDML against trained baseline paradigms (fair comparison).")
    parser.add_argument("--config", type=str, default="configs/halfcheetah_v5_default.yaml", help="Path to config YAML")
    parser.add_argument("--checkpoint", type=str, default="checkpoints/halfcheetah_v5/best_model.pt", help="Path to trained HDML checkpoint")
    parser.add_argument("--seed", type=int, default=42)
    parser.add_argument("--output-dir", default="results/corrected")
    parser.add_argument("--episodes", type=int, default=5, help="Episodes per evaluation")
    parser.add_argument("--device", type=str, default="cuda", help="Execution device")
    args = parser.parse_args()

    cfg_path = args.config
    ckpt_path = args.checkpoint
    if not Path(cfg_path).is_file():
        raise FileNotFoundError(f"Requested config does not exist: {cfg_path}")
    if not Path(ckpt_path).is_file():
        raise FileNotFoundError(f"Requested HDML checkpoint does not exist: {ckpt_path}")

    cfg = HDMLConfig.from_yaml(cfg_path)
    device = torch.device(args.device)
    if device.type == "cuda" and not torch.cuda.is_available():
        raise RuntimeError("CUDA requested but unavailable; no CPU benchmark was substituted")
    logger.info(f"Execution hardware: {device}")
    baseline_ckpt_dir = Path(ckpt_path).parent / "baselines"

    # 1. Instantiate HDML (Trained)
    hdml_model = HDMLModel.from_config(cfg.model).to(device)
    state_mean = None
    state_std = None
    if Path(ckpt_path).exists():
        logger.info(f"Loading trained HDML checkpoint: {ckpt_path}")
        ckpt = torch.load(ckpt_path, map_location=device, weights_only=False)
        hdml_model.load_state_dict(ckpt["model_state_dict"])
        state_mean = ckpt.get("state_mean")
        state_std = ckpt.get("state_std")
    else:
        raise FileNotFoundError(f"Missing HDML checkpoint: {ckpt_path}")

    if state_mean is None or state_std is None:
        raise ValueError("Checkpoint is missing training normalization statistics")
    for model_type in ("diffusion", "dt", "iql", "rnn", "mlp"):
        candidate = baseline_ckpt_dir / f"{model_type}_best.pt"
        if not candidate.is_file():
            raise FileNotFoundError(f"Missing trained baseline checkpoint: {candidate}")
        baseline_state = torch.load(candidate, map_location="cpu", weights_only=False)
        for key, expected in (("state_mean", state_mean), ("state_std", state_std)):
            actual = baseline_state.get(key)
            if actual is None or np.shape(actual) != np.shape(expected) or not np.allclose(actual, expected):
                raise ValueError(f"Training normalization differs or is missing: {candidate}, {key}")

    # 2. Instantiate SOTA Baselines (loading trained checkpoints when available)
    diffusion_model = DiffusionPolicyBaseline(
        prop_dim=cfg.model.prop_dim, action_dim=cfg.model.action_dim, d_model=cfg.model.d_model, denoising_steps=10
    ).to(device)
    load_baseline_checkpoint(diffusion_model, baseline_ckpt_dir, "diffusion", device)

    dt_model = DecisionTransformerBaseline(
        prop_dim=cfg.model.prop_dim, action_dim=cfg.model.action_dim, d_model=cfg.model.d_model, num_layers=cfg.model.num_mamba_layers
    ).to(device)
    load_baseline_checkpoint(dt_model, baseline_ckpt_dir, "dt", device)

    iql_model = IQLBaseline(
        prop_dim=cfg.model.prop_dim, action_dim=cfg.model.action_dim, hidden_dim=256
    ).to(device)
    load_baseline_checkpoint(iql_model, baseline_ckpt_dir, "iql", device)

    rnn_model = DecisionRNNBaseline(
        prop_dim=cfg.model.prop_dim, action_dim=cfg.model.action_dim, d_model=cfg.model.d_model,
        num_layers=cfg.model.num_mamba_layers,
    ).to(device)
    load_baseline_checkpoint(rnn_model, baseline_ckpt_dir, "rnn", device)

    mlp_model = MLPBCBaseline(
        prop_dim=cfg.model.prop_dim, action_dim=cfg.model.action_dim, hidden_dim=256
    ).to(device)
    load_baseline_checkpoint(mlp_model, baseline_ckpt_dir, "mlp", device)

    models_to_test = [
        ("HDML (Decision Mamba + Liquid CfC - Ours)", hdml_model, "hdml"),
        ("Diffusion Policy (DDPM 10-step Denoising)", diffusion_model, "diffusion"),
        ("Decision Transformer (Causal Attention DT)", dt_model, "dt"),
        ("Implicit Q-Learning (IQL / Value-Advantage)", iql_model, "iql"),
        ("Decision RNN (LSTM Recurrent Policy)", rnn_model, "rnn"),
        ("MLP-BC (Standard Feedforward Reactive)", mlp_model, "mlp"),
    ]

    print("\n" + "=" * 115)
    print(f"ACADEMIC BENCHMARK COMPARISON ON {cfg.env.env_name.upper()} (Standard & Perturbed Robustness, Trained Baselines)")
    print("=" * 115)

    results_std: list[dict[str, Any]] = []
    results_rob: list[dict[str, Any]] = []

    for name, model, mtype in models_to_test:
        logger.info(f"Running Standard Benchmark on: {name}...")
        res_s = evaluate_policy(
            model=model,
            model_type=mtype,
            env_name=cfg.env.env_name,
            num_episodes=args.episodes,
            seed=args.seed,
            context_length=cfg.training.context_length,
            target_return=cfg.env.target_return,
            scale_return=cfg.env.scale_return,
            state_mean=state_mean,
            state_std=state_std,
            with_perturbations=False,
            device=device,
        )
        res_s["name"] = name
        results_std.append(res_s)

        logger.info(f"Running Perturbation Benchmark on: {name}...")
        res_r = evaluate_policy(
            model=model,
            model_type=mtype,
            env_name=cfg.env.env_name,
            num_episodes=args.episodes,
            seed=args.seed,
            context_length=cfg.training.context_length,
            target_return=cfg.env.target_return,
            scale_return=cfg.env.scale_return,
            state_mean=state_mean,
            state_std=state_std,
            with_perturbations=True,
            device=device,
        )
        res_r["name"] = name
        results_rob.append(res_r)

    # -------------------------------------------------------------
    # RLIABLE STATISTICAL ANALYSIS & PUBLICATION METRICS
    # -------------------------------------------------------------
    from hdml.utils.rliable_metrics import (
        compute_iqm,
        stratified_bootstrap_ci,
        compute_probability_of_improvement,
        generate_rliable_summary_plot,
    )

    std_scores_dict = {res["name"]: res["norm_scores_array"] for res in results_std}
    rob_scores_dict = {res["name"]: res["norm_scores_array"] for res in results_rob}

    # Generate 3-panel publication figure
    Path(args.output_dir).mkdir(parents=True, exist_ok=True)
    plot_path = Path(args.output_dir) / f"rliable_{cfg.env.env_name.lower()}_benchmark.png"
    generate_rliable_summary_plot(std_scores_dict, env_name=cfg.env.env_name, save_path=str(plot_path))

    # Print Publication Comparative Tables
    print("\n" + "=" * 125)
    print(f"ACADEMIC BENCHMARK COMPARISON ON {cfg.env.env_name.upper()} (RLIABLE STATISTICAL PROTOCOL)")
    print("=" * 125)
    print(
        f"{'Architecture / Paradigm':<44} | {'Params':<9} | {'Freq (Hz)':<10} | {'Latency':<10} | {'Jerk (Smooth)':<14} | {'IQM (95% Bootstrap CI)':<26}"
    )
    print("-" * 125)
    for res in results_std:
        iqm_pt, ci_lo, ci_hi = stratified_bootstrap_ci(res["norm_scores_array"], stat_fn=compute_iqm)
        ci_str = f"{iqm_pt:.2f} [{ci_lo:.2f}, {ci_hi:.2f}]"
        print(
            f"{res['name']:<44} | {res['params_count']:<9,d} | {res['frequency_hz']:<10.1f} | {res['mean_latency_ms']:<8.2f}ms | {res['mean_smoothness_jerk']:<14.4f} | {ci_str:<26}"
        )
    print("-" * 125)

    print("\n" + "-" * 125)
    print(f"PERTURBATION ROBUSTNESS (Random Force Impulses & Continuous Sensor Noise)")
    print("-" * 125)
    print(
        f"{'Architecture / Paradigm':<44} | {'Raw Return':<20} | {'Perturbed IQM (95% CI)':<26} | {'Jerk (Smooth)':<14} | {'Complete %':<10}"
    )
    print("-" * 125)
    for res in results_rob:
        iqm_pt, ci_lo, ci_hi = stratified_bootstrap_ci(res["norm_scores_array"], stat_fn=compute_iqm)
        ci_str = f"{iqm_pt:.2f} [{ci_lo:.2f}, {ci_hi:.2f}]"
        ret_str = f"{res['mean_return']:.2f} +/- {res['std_return']:.2f}"
        print(
            f"{res['name']:<44} | {ret_str:<20} | {ci_str:<26} | {res['mean_smoothness_jerk']:<14.4f} | {res['episode_completion_rate']:<10.1f}%"
        )
    print("-" * 125)

    print("\n" + "-" * 125)
    print("PROBABILITY OF IMPROVEMENT (Mann-Whitney U Bootstrap Statistic: P(HDML > Baseline))")
    print("-" * 125)
    hdml_std_scores = results_std[0]["norm_scores_array"]
    for res in results_std[1:]:
        p_val, p_lo, p_hi = compute_probability_of_improvement(hdml_std_scores, res["norm_scores_array"])
        print(f"  P( HDML > {res['name']:<42} ) = {p_val * 100.0:6.2f}%  [95% CI: {p_lo * 100.0:5.2f}% - {p_hi * 100.0:5.2f}%]")
    print("-" * 125 + "\n")

    # Save to results text file
    res_file = Path(args.output_dir) / f"benchmark_{cfg.env.env_name.lower()}.txt"
    res_file.parent.mkdir(parents=True, exist_ok=True)
    with open(res_file, "w") as f:
        f.write(f"HDML RLIABLE BENCHMARK RESULTS - {cfg.env.env_name}\n")
        f.write("=" * 100 + "\n\n")
        f.write("STANDARD BENCHMARK:\n")
        for res in results_std:
            point_est, ci_lo, ci_hi = stratified_bootstrap_ci(res["norm_scores_array"], stat_fn=compute_iqm)
            f.write(f"- {res['name']}:\n")
            f.write(f"    IQM (95% CI): {point_est:.2f} [{ci_lo:.2f}, {ci_hi:.2f}]\n")
            f.write(f"    D4RL Mean Score: {res['d4rl_normalized_score']:.2f}\n")
            f.write(f"    Raw Return: {res['mean_return']:.2f} +/- {res['std_return']:.2f}\n")
            f.write(f"    Smoothness (Jerk): {res['mean_smoothness_jerk']:.4f}\n")
            f.write(f"    Inference Latency: {res['mean_latency_ms']:.2f} ms ({res['frequency_hz']:.1f} Hz)\n")
            f.write(f"    Parameters: {res['params_count']:,}\n\n")
        f.write("PERTURBATION ROBUSTNESS BENCHMARK:\n")
        for res in results_rob:
            point_est, ci_lo, ci_hi = stratified_bootstrap_ci(res["norm_scores_array"], stat_fn=compute_iqm)
            f.write(f"- {res['name']}:\n")
            f.write(f"    Perturbed IQM (95% CI): {point_est:.2f} [{ci_lo:.2f}, {ci_hi:.2f}]\n")
            f.write(f"    Episode Completion Rate (not a safety metric): {res['episode_completion_rate']:.1f}%\n")
            f.write(f"    Smoothness (Jerk): {res['mean_smoothness_jerk']:.4f}\n\n")
    def serializable(result):
        return {k: v.tolist() if isinstance(v, np.ndarray) else v for k, v in result.items()}
    artifacts = [Path(ckpt_path)] + [baseline_ckpt_dir / f"{m}_best.pt" for m in ("dt", "rnn", "diffusion", "iql", "mlp")]
    raw = {
        "protocol_version": 2, "created_utc": datetime.now(timezone.utc).isoformat(),
        "config": {"model": vars(cfg.model), "training": vars(cfg.training), "env": vars(cfg.env)},
        "evaluation_seed": args.seed, "episodes": args.episodes,
        "uncertainty_scope": "episodes of one checkpoint per model, not independent training seeds",
        "perturbation": {"kind": "action_additive_uniform", "probability": 0.05, "magnitude": 0.6,
                         "sensor_std": 0.05, "sensor_dropout_probability": 0.02},
        "checkpoint_sha256": {str(p): hashlib.sha256(p.read_bytes()).hexdigest() for p in artifacts},
        "standard": [serializable(x) for x in results_std],
        "perturbed": [serializable(x) for x in results_rob],
    }
    res_file.with_suffix(".json").write_text(json.dumps(raw, indent=2), encoding="utf-8")
    logger.info(f"Wrote benchmark report to: {res_file}")


if __name__ == "__main__":
    main()

